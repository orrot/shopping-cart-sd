package com.orrot.store.shoppingcart.adapter.input.model;

public record IdentityId(Object id) {
}

package com.orrot.store.shoppingcart.adapter.input.model;

public record PaymentMethodView(String code, String name) {
}

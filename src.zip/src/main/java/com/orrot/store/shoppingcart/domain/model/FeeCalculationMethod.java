package com.orrot.store.shoppingcart.domain.model;

public enum FeeCalculationMethod {
    FIXED,
    PERCENTAGE
}

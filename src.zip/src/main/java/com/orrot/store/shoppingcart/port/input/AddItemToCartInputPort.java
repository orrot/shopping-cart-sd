package com.orrot.store.shoppingcart.port.input;

import com.orrot.store.shoppingcart.port.usecases.AddItemToCartUseCase;
import org.springframework.stereotype.Service;

@Service
public class AddItemToCartInputPort implements AddItemToCartUseCase {

}

package com.orrot.store.shoppingcart.port.input;

import com.orrot.store.shoppingcart.port.usecases.AddItemToCartUseCase;
import com.orrot.store.shoppingcart.port.usecases.CreateCartUseCase;
import org.springframework.stereotype.Service;

@Service
public class CreateCartInputPort implements CreateCartUseCase {

}

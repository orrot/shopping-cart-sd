package com.orrot.store.shoppingcart.port.output;

public interface ProductOutputPort {
}

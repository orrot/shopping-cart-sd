package com.orrot.store.shoppingcart.port.usecases;

// POST /carts/{cartId}/item
// DELETE /carts/{cartId}/item/{itemId}
public interface AddItemToCartUseCase {
}

package com.orrot.store.shoppingcart.port.usecases;

// It could be named "ForAddingItemToCart".
public interface UpdateCartPaymentMethodUseCase {
}
